"use client";

import Image from "next/image";
import {
  ArrowLeft,
  Armchair,
  Building2,
  CalendarCheck2,
  ClipboardCheck,
  House,
  MoonStar,
  Radiation,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import {
  ConferenceLayoutEditor,
  type LayoutEditorAddition,
} from "@/components/saudident/ConferenceLayoutEditor";
import savedAbhaTourLayout from "@/data/abha-tour-layout.json";
import savedConferenceLayout from "@/data/conference-layout.json";
import {
  abhaTourItemLabels,
  abhaTourScenes,
  type AbhaTourItemKind,
  type AbhaTourOverlay,
} from "@/data/abha-tour";
import { gsap } from "@/lib/gsap";

type AbhaTourExperienceProps = {
  onReturnToBranches: () => void;
  cinematicEnabled?: boolean;
  onCalibrationChange?: (active: boolean) => void;
};

const ITEM_KINDS: AbhaTourItemKind[] = [
  "arrow",
  "clinic",
  "sterilization",
  "reception",
  "lounge",
  "prayer",
  "radiology",
  "examination",
  "administration",
];

type SavedPlacement = {
  x: number;
  y: number;
  scale: number;
  angle?: number;
  tilt?: number;
  depth?: number;
};

const savedPositions = savedConferenceLayout as Record<string, SavedPlacement>;

function FloorRouteGuide() {
  return (
    <span className="sd-conference-floor-arrow__projection" aria-hidden="true">
      <svg viewBox="0 0 100 180" focusable="false">
        <path className="sd-route-chevron sd-route-chevron--large" d="M8 142 50 100 92 142 72 162 50 140 28 162Z" />
        <path className="sd-route-chevron sd-route-chevron--medium" d="M19 99 50 68 81 99 66 114 50 98 34 114Z" />
        <path className="sd-route-chevron sd-route-chevron--small" d="M30 57 50 37 70 57 60 67 50 57 40 67Z" />
      </svg>
    </span>
  );
}

function ItemIcon({ kind }: { kind: AbhaTourItemKind }) {
  if (kind === "clinic") return <Stethoscope aria-hidden="true" />;
  if (kind === "reception") return <CalendarCheck2 aria-hidden="true" />;
  if (kind === "lounge") return <Armchair aria-hidden="true" />;
  if (kind === "prayer") return <MoonStar aria-hidden="true" />;
  if (kind === "radiology") return <Radiation aria-hidden="true" />;
  if (kind === "examination") return <ClipboardCheck aria-hidden="true" />;
  if (kind === "administration") return <Building2 aria-hidden="true" />;
  if (kind === "sterilization") return <ShieldCheck aria-hidden="true" />;
  return <ArrowLeft aria-hidden="true" />;
}

const EDITOR_ADDITIONS: LayoutEditorAddition[] = ITEM_KINDS.map((kind) => ({
  id: kind,
  label: abhaTourItemLabels[kind],
  icon: <ItemIcon kind={kind} />,
}));

export function AbhaTourExperience({
  onReturnToBranches,
  cinematicEnabled = true,
  onCalibrationChange,
}: AbhaTourExperienceProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const transitionRef = useRef<gsap.core.Timeline | null>(null);
  const transitionLockedRef = useRef(false);
  const [sceneIndex, setSceneIndex] = useState(0);
  const [items, setItems] = useState<AbhaTourOverlay[]>(() => savedAbhaTourLayout as AbhaTourOverlay[]);
  const [announcement, setAnnouncement] = useState("");
  const [transitioning, setTransitioning] = useState(false);
  const [calibrationActive, setCalibrationActive] = useState(process.env.NODE_ENV === "development");
  const scene = abhaTourScenes[sceneIndex];
  const sceneItems = useMemo(
    () => items.filter((item) => item.sceneId === scene.id),
    [items, scene.id],
  );

  const goToScene = useCallback((index: number) => {
    if (transitionLockedRef.current) return;
    const targetIndex = (index + abhaTourScenes.length) % abhaTourScenes.length;
    if (targetIndex === sceneIndex) return;
    const direction = targetIndex === 0 && sceneIndex === abhaTourScenes.length - 1
      ? 1
      : targetIndex > sceneIndex ? 1 : -1;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const root = rootRef.current;
    const currentMedia = root?.querySelector<HTMLElement>(".sd-abha-tour__media");
    const currentControls = root?.querySelector<HTMLElement>(".sd-abha-tour__controls");
    const light = root?.querySelector<HTMLElement>(".sd-abha-tour__transition-light");

    setAnnouncement("");
    if (!cinematicEnabled || calibrationActive || reducedMotion || !currentMedia) {
      setSceneIndex(targetIndex);
      return;
    }

    transitionLockedRef.current = true;
    setTransitioning(true);
    transitionRef.current?.kill();

    const revealIncoming = () => {
      setSceneIndex(targetIndex);
      window.requestAnimationFrame(() => {
        const incomingMedia = rootRef.current?.querySelector<HTMLElement>(".sd-abha-tour__media");
        const incomingControls = rootRef.current?.querySelectorAll<HTMLElement>(".sd-abha-tour-control");
        if (!incomingMedia) {
          transitionLockedRef.current = false;
          setTransitioning(false);
          return;
        }
        gsap.fromTo(
          incomingMedia,
          { autoAlpha: 0.16, xPercent: 3.5 * direction, scale: 1.045, filter: "blur(8px) brightness(1.08)" },
          {
            autoAlpha: 1,
            xPercent: 0,
            scale: 1,
            filter: "blur(0px) brightness(1)",
            duration: 0.86,
            ease: "power3.out",
            clearProps: "transform,filter,opacity,visibility",
            onComplete: () => {
              transitionLockedRef.current = false;
              setTransitioning(false);
            },
          },
        );
        if (incomingControls?.length) {
          gsap.fromTo(
            incomingControls,
            { autoAlpha: 0, y: 12, scale: 0.9 },
            { autoAlpha: 1, y: 0, scale: 1, duration: 0.42, stagger: 0.08, delay: 0.38, ease: "back.out(1.6)", clearProps: "transform,opacity,visibility" },
          );
        }
      });
    };

    const timeline = gsap.timeline({ defaults: { overwrite: "auto" }, onComplete: revealIncoming });
    transitionRef.current = timeline;
    if (currentControls) timeline.to(currentControls, { autoAlpha: 0, duration: 0.22, ease: "power2.in" }, 0);
    timeline.to(currentMedia, {
      xPercent: -3.5 * direction,
      scale: 1.055,
      filter: "blur(7px) brightness(1.06)",
      autoAlpha: 0.14,
      duration: 0.62,
      ease: "power3.in",
    }, 0);
    if (light) {
      timeline.fromTo(
        light,
        { autoAlpha: 0, xPercent: 85 * direction },
        { autoAlpha: 0.72, xPercent: -85 * direction, duration: 0.58, ease: "power2.inOut" },
        0.08,
      );
      timeline.to(light, { autoAlpha: 0, duration: 0.28, ease: "power2.out" }, 0.48);
    }
  }, [calibrationActive, cinematicEnabled, sceneIndex]);

  useEffect(() => {
    const nextIndex = (sceneIndex + 1) % abhaTourScenes.length;
    const previousIndex = (sceneIndex - 1 + abhaTourScenes.length) % abhaTourScenes.length;
    const nextImage = new window.Image();
    const previousImage = new window.Image();
    nextImage.src = abhaTourScenes[nextIndex].image;
    previousImage.src = abhaTourScenes[previousIndex].image;
  }, [sceneIndex]);

  useEffect(() => () => {
    transitionRef.current?.kill();
  }, []);

  const handleEditingChange = useCallback((active: boolean) => {
    setCalibrationActive(active);
    onCalibrationChange?.(active);
    if (!active) return;
    transitionRef.current?.kill();
    transitionLockedRef.current = false;
    setTransitioning(false);
    const media = rootRef.current?.querySelector<HTMLElement>(".sd-abha-tour__media");
    const controls = rootRef.current?.querySelector<HTMLElement>(".sd-abha-tour__controls");
    if (media) gsap.set(media, { clearProps: "transform,filter,opacity,visibility" });
    if (controls) gsap.set(controls, { clearProps: "opacity,visibility" });
  }, [onCalibrationChange]);

  const saveItems = useCallback(async (nextItems: AbhaTourOverlay[]) => {
    try {
      await fetch("/api/abha-tour-layout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextItems),
      });
    } catch {
      // Positioning errors are reported by the shared layout editor.
    }
  }, []);

  const addItem = useCallback((rawKind: string) => {
    const kind = rawKind as AbhaTourItemKind;
    if (!ITEM_KINDS.includes(kind)) return;
    const sameKindCount = items.filter((item) => item.sceneId === scene.id && item.kind === kind).length;
    let suffix = sameKindCount + 1;
    while (items.some((item) => item.id === `${scene.id}-${kind}-${suffix}`)) suffix += 1;
    const item: AbhaTourOverlay = {
      id: `${scene.id}-${kind}-${suffix}`,
      sceneId: scene.id,
      kind,
      x: 50 + ((sameKindCount % 3) - 1) * 8,
      y: 60 + Math.floor(sameKindCount / 3) * 7,
      scale: 1,
      angle: 0,
      tilt: 70,
      depth: 0.78,
    };
    const nextItems = [...items, item];
    setItems(nextItems);
    void saveItems(nextItems);
  }, [items, saveItems, scene.id]);

  const removeItem = useCallback((id: string) => {
    const nextItems = items.filter((item) => item.id !== id || item.required);
    if (nextItems.length === items.length) return;
    setItems(nextItems);
    void saveItems(nextItems);
  }, [items, saveItems]);

  const itemPosition = (item: AbhaTourOverlay) => ({
    left: `${savedPositions[`${item.sceneId}:${item.id}`]?.x ?? item.x}%`,
    top: `${savedPositions[`${item.sceneId}:${item.id}`]?.y ?? item.y}%`,
    "--sd-layout-scale": savedPositions[`${item.sceneId}:${item.id}`]?.scale ?? item.scale,
    "--sd-layout-angle": `${savedPositions[`${item.sceneId}:${item.id}`]?.angle ?? item.angle}deg`,
    "--sd-layout-tilt": `${savedPositions[`${item.sceneId}:${item.id}`]?.tilt ?? item.tilt}deg`,
    "--sd-layout-depth": savedPositions[`${item.sceneId}:${item.id}`]?.depth ?? item.depth,
  }) as CSSProperties;

  return (
    <div
      ref={rootRef}
      className={`sd-abha-tour${cinematicEnabled ? " is-cinematic" : ""}${calibrationActive ? " is-calibrating" : ""}${transitioning ? " is-transitioning" : ""}`}
      role="region"
      aria-label="الجولة التفاعلية في فرع أبها"
    >
      <div className="sd-abha-tour__media" key={scene.id}>
        <Image className="sd-abha-tour__photo" src={scene.image} alt={scene.alt} fill priority sizes="100vw" />

        <div className="sd-abha-tour__controls sd-conference-image-coordinates" aria-label={`عناصر الصورة رقم ${scene.number}`}>
          {sceneItems.map((item) => item.kind === "arrow" ? (
            <button
              type="button"
              key={item.id}
              data-layout-id={item.id}
              data-layout-control={`${item.sceneId}:${item.id}`}
              data-layout-removable={item.required ? undefined : "true"}
              className="sd-conference-floor-arrow sd-abha-tour-control sd-abha-tour-arrow"
              style={itemPosition(item)}
              onClick={() => goToScene(sceneIndex + 1)}
              aria-label={`الانتقال إلى الصورة ${scene.number === 11 ? 1 : scene.number + 1}`}
            >
              <FloorRouteGuide />
            </button>
          ) : (
            <button
              type="button"
              key={item.id}
              data-layout-id={item.id}
              data-layout-control={`${item.sceneId}:${item.id}`}
              data-layout-removable={item.required ? undefined : "true"}
              className="sd-corridor-hotspot sd-abha-tour-control"
              style={itemPosition(item)}
              onClick={() => setAnnouncement(`تم اختيار ${abhaTourItemLabels[item.kind]}`)}
              aria-label={abhaTourItemLabels[item.kind]}
            >
              <span className="sd-corridor-hotspot__pulse" aria-hidden="true" />
              <span className="sd-corridor-hotspot__icon"><ItemIcon kind={item.kind} /></span>
              <strong>{abhaTourItemLabels[item.kind]}</strong>
            </button>
          ))}
        </div>
      </div>

      <div className="sd-abha-tour__transition-light" aria-hidden="true" />

      <button
        type="button"
        className="sd-branch-choice-return sd-abha-tour__branch-return"
        onClick={onReturnToBranches}
        disabled={transitioning}
        aria-label="العودة إلى اختيار الفرع"
      >
        <Building2 aria-hidden="true" />
        <span>اختيار الفرع</span>
      </button>

      {sceneIndex > 0 && (
        <button
          type="button"
          className="sd-conference-back sd-abha-tour__back"
          onClick={() => goToScene(sceneIndex - 1)}
          disabled={transitioning}
          aria-label="العودة إلى الصورة السابقة"
        >
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M5 12h14M14 6l6 6-6 6" />
          </svg>
          <span>رجوع</span>
        </button>
      )}

      {sceneIndex === abhaTourScenes.length - 1 && (
        <button
          type="button"
          className="sd-abha-tour__home"
          onClick={() => goToScene(0)}
          disabled={transitioning}
          aria-label="العودة إلى الصورة الأولى"
        >
          <House aria-hidden="true" />
          <span>الرئيسية</span>
        </button>
      )}

      <p className="sd-abha-tour__announcement" aria-live="polite">{announcement}</p>

      <ConferenceLayoutEditor
        key={scene.id}
        rootRef={rootRef}
        activeScene={scene.id}
        additions={EDITOR_ADDITIONS}
        onAddControl={addItem}
        onRemoveControl={removeItem}
        onEditingChange={handleEditingChange}
        refreshKey={sceneItems.length}
      />
    </div>
  );
}
